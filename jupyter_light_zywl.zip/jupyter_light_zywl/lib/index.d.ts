import { JupyterFrontEndPlugin } from '@jupyterlab/application';
/**
 * Initialization data for the jupyter-light-zywl extension.
 */
declare const plugin: JupyterFrontEndPlugin<void>;
export default plugin;
